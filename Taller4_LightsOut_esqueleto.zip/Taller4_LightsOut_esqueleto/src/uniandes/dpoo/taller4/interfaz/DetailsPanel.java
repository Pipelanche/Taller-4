package uniandes.dpoo.taller4.interfaz;

import java.awt.*;
import javax.swing.*;

public class DetailsPanel extends JPanel {

	private JTextField txtJugadas;
	private JTextField txtJugador;

	public DetailsPanel() {
		initUI();
	}

	private void initUI() {
	    setLayout(new GridLayout(1, 4, 5, 0));
	    
	    JLabel jugadasLabel = createLabel("Jugadas:");
	    txtJugadas = createTextField();
	    
	    JLabel jugadorLabel = createLabel("Jugador:");
	    txtJugador = createTextField();
	    
	    txtJugadas.setEditable(false);
	    txtJugador.setEditable(false);
	    
	    add(jugadasLabel);
	    add(txtJugadas);
	    add(jugadorLabel);
	    add(txtJugador);
	}
	
	private JLabel createLabel(String text) {
	    JLabel label = new JLabel(text);
	    Font font = label.getFont().deriveFont(Font.PLAIN);
	    label.setFont(font);
	    return label;
	}
	
	private JTextField createTextField() {
	    JTextField textField = new JTextField();
	    return textField;
	}
	
	public String getJugadas() {
	    return txtJugadas.getText();
	}
	
	public String getJugador() {
	    return txtJugador.getText();
	}
	
	public void setJugador(String nombre) {
	    txtJugador.setText(nombre);
	}
	
	public void setJugadas(int jugadas) {
	    txtJugadas.setText(String.valueOf(jugadas));
}
}
