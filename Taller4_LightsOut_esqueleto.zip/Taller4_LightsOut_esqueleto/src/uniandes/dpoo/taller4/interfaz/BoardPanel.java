package uniandes.dpoo.taller4.interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

import uniandes.dpoo.taller4.modelo.Tablero;

public class BoardPanel extends JPanel {
	
	private final Tablero tableroDeJuego;
	private final BufferedImage imagenLuz;
	private final MainPanel padre;
	
	public BoardPanel(MainPanel padre, int tamanioTablero) {
	    this.tableroDeJuego = new Tablero(tamanioTablero);
	    this.padre = padre;
	
	    // Cargar imagen de luz
	    Path path = Paths.get("data/luz.png");
	    try {
	        this.imagenLuz = ImageIO.read(path.toFile());
	    } catch (IOException e) {
	        throw new RuntimeException("No se pudo cargar la imagen de luz", e);
	    }
	
	    // Establecer dise�o del panel y a�adir MouseAdapter
	    setLayout(new BorderLayout());
	    addMouseListener(new MouseAdapter() {
	        @Override
	        public void mouseClicked(MouseEvent e) {
	            if (!isEnabled()) {
	                return;
	            }
	
	            int click_x = e.getX();
	            int click_y = e.getY();
	            int[] casilla = convertirCoordenadasACasilla(click_x, click_y);
	            tableroDeJuego.jugar(casilla[0], casilla[1]);
	            repaint();
	        }
	    });
	}
	
	@Override
	public void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    Graphics2D g2d = (Graphics2D) g;
	    g2d.setColor(Color.WHITE);
	    g2d.fillRect(0, 0, getWidth(), getHeight());
	    int filas = tableroDeJuego.darTablero().length;
	    int columnas = tableroDeJuego.darTablero()[0].length;
	    double anchoCasilla = (double) getWidth() / columnas;
	    double altoCasilla = (double) getHeight() / filas;
	    for (int fila = 0; fila < filas; fila++) {
	        for (int columna = 0; columna < columnas; columna++) {
	            RoundRectangle2D.Double rect = new RoundRectangle2D.Double(
	                    columna * anchoCasilla + 1, fila * altoCasilla + 1,
	                    anchoCasilla - 1, altoCasilla - 1, 5, 5);
	            if (tableroDeJuego.darTablero()[fila][columna]) {
	                g2d.setPaint(new GradientPaint(
	                        (int) (columna * anchoCasilla) + 1,
	                        (int) (fila * altoCasilla) + 1,
	                        Color.YELLOW,
	                        (int) ((columna * anchoCasilla) + 1 + anchoCasilla),
	                        (int) ((fila * altoCasilla) + 1 + altoCasilla),
	                        Color.WHITE));
	            } else {
	                g2d.setPaint(new GradientPaint(
	                        (int) (columna * anchoCasilla) + 1,
	                        (int) (fila * altoCasilla) + 1,
	                        Color.WHITE,
	                        (int) ((columna * anchoCasilla) + 1 + anchoCasilla),
	                        (int) ((fila * altoCasilla) + 1 + altoCasilla),
	                        Color.GRAY));
	            }
	            g2d.fill(rect);
	            g2d.setPaint(null);
	            g2d.drawImage(imagenLuz, (int) (columna * anchoCasilla),
	            	(int) (fila * altoCasilla), (int) anchoCasilla,
	            	(int) altoCasilla, null);
	            }
	        }
	    }

	private int[] convertirCoordenadasACasilla(int x, int y) {
		int filas = tableroDeJuego.darTablero().length;
		int columnas = tableroDeJuego.darTablero()[0].length;
		double anchoCasilla = (double) getWidth() / columnas;
		double altoCasilla = (double) getHeight() / filas;
		int fila = (int) (y / altoCasilla);
		int columna = (int) (x / anchoCasilla);
		return new int[] { fila, columna };
	}
	
	public void habilitar() {
		setEnabled(true);
	}
	
	public void deshabilitar() {
		setEnabled(false);
	}
	
	public void actualizar() {
		repaint();
	}
	
	public void reiniciarTablero() {
	tableroDeJuego.reiniciar();
		actualizar();
		}
	
    /*private boolean[][] lights;
    private int dimensions;

    public void Board(int dimensions) {
        this.dimensions = dimensions;
        lights = new boolean[dimensions][dimensions];
    }

    public void newGame(int dimensions) {
        this.dimensions = dimensions;
        lights = new boolean[dimensions][dimensions];
        randomize();
    }

    public void press(int row, int col) {
        toggle(row, col);
        if (row > 0) toggle(row - 1, col);
        if (row < dimensions - 1) toggle(row + 1, col);
        if (col > 0) toggle(row, col - 1);
        if (col < dimensions - 1) toggle(row, col + 1);
    }
    
    public void randomize() {
        for (int row = 0; row < dimensions; row++) {
            for (int col = 0; col < dimensions; col++) {
                lights[row][col] = Math.random() < 0.5;
            }
        } }

    public void toggle(int row, int col) {
        lights[row][col] = !lights[row][col];
    }*/
	}
	
