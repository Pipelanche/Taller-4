package uniandes.dpoo.taller4.interfaz;

import java.awt.*;
import java.awt.event.*;
//import java.awt.geom.Dimension2D;
import javax.swing.*;

public class MainPanel extends JPanel implements ActionListener {
    
    private static final String NUEVO = "Nuevo";
    private static final String REINICIAR = "Reiniciar";
    private static final String TOP10 = "Top-10";
    private static final String CAMBIAR_JUGADOR = "Cambiar jugador";
    
    private JButton nuevoBtn, reiniciarBtn, top10Btn, cambiarJugadorBtn;
    
    private BoardPanel panelTablero;
    private ConfigPanel panelConfiguracion;
    private DetailsPanel panelDetalles;
    private LightsOut padre;
    
    public MainPanel(LightsOut padre) {
        setLayout(new BorderLayout());
        this.padre = padre;
        
        JPanel botonesPanel = new JPanel();
        botonesPanel.setLayout(new GridLayout(4, 1, 0, 10));
        
        nuevoBtn = crearBoton(NUEVO);
        botonesPanel.add(nuevoBtn);
        reiniciarBtn = crearBoton(REINICIAR);
        botonesPanel.add(reiniciarBtn);
        top10Btn = crearBoton(TOP10);
        botonesPanel.add(top10Btn);
        cambiarJugadorBtn = crearBoton(CAMBIAR_JUGADOR);
        botonesPanel.add(cambiarJugadorBtn);
        
        JPanel menuPanel = new JPanel(new BorderLayout());
        menuPanel.setBackground(Color.WHITE);
        menuPanel.add(botonesPanel, BorderLayout.CENTER);
        
        panelConfiguracion = new ConfigPanel();
        panelTablero = new BoardPanel(this, 3); 
        panelTablero.setEnabled(false);
        panelDetalles = new DetailsPanel();
        
        add(panelConfiguracion, BorderLayout.NORTH);
        add(panelTablero, BorderLayout.CENTER);
        add(menuPanel, BorderLayout.EAST);
        add(panelDetalles, BorderLayout.SOUTH);
        
        setPreferredSize(new Dimension(500, 500));
    }
        
    /*public int getDimensions() {
            return (Integer) dimensionsComboBox.getSelectedItem();
    } */
    
    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.addActionListener(this);
        boton.setActionCommand(texto);
        boton.setBackground(new Color(42, 137, 224));
        boton.setForeground(Color.WHITE);
        boton.setFont(boton.getFont().deriveFont(Font.PLAIN));
        return boton;
    }
    
    public void actionPerformed(ActionEvent event) {
        String comando = event.getActionCommand();
        switch (comando) {
            case NUEVO:
                panelTablero.reiniciarTablero();
                break;
            case REINICIAR:
                panelTablero.reiniciarTablero();
                break;
            case TOP10:
                padre.getTop10();
                break;
        }
    } }