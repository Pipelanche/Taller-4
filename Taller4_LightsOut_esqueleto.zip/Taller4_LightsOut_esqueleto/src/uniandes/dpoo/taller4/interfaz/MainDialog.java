package uniandes.dpoo.taller4.interfaz;

//import java.awt.*;
import uniandes.dpoo.taller4.modelo.*;


import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainDialog extends JDialog {

    private static final int DIALOG_WIDTH = 410;
    private static final int DIALOG_HEIGHT = 210;

    private final Top10 top10;
    private final JList<String> topList;

    public MainDialog(Top10 top10) {
        this.top10 = top10;

        setTitle("Top 10");
        setModal(true);
        setResizable(false);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        setSize(DIALOG_WIDTH, DIALOG_HEIGHT);

        topList = new JList<>(new DefaultListModel<>());
        topList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(topList);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        add(scrollPane, BorderLayout.CENTER);

        actualizarListaTop10();
    }

    private void actualizarListaTop10() {
        DefaultListModel<String> model = (DefaultListModel<String>) topList.getModel();
        model.clear();

        List<RegistroTop10> registros = (List<RegistroTop10>) top10.darRegistros();
        for (RegistroTop10 registro : registros) {
            model.addElement(registro.toString());
        }
    }
}

