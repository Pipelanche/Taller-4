package uniandes.dpoo.taller4.interfaz;

import uniandes.dpoo.taller4.modelo.RegistroTop10;
import uniandes.dpoo.taller4.modelo.Top10;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class LightsOut extends JFrame {
    private BoardPanel board;
    private Top10 top10;
    private File top10File;
    private MainPanel mainPanel;

    public LightsOut() {
        setTitle("LightsOut");
        setSize(500, 500);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        this.mainPanel = new MainPanel(this);
        add(mainPanel, BorderLayout.CENTER);

        //mainPanel.getDimensions();
        top10 = new Top10();
        top10File = new File("data/top10.csv");
        top10.cargarRecords(top10File);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                try {
                    saveTop10();
                } catch (FileNotFoundException | UnsupportedEncodingException exception) {
                    exception.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args) {
        LightsOut window = new LightsOut();
        window.setVisible(true);
    }

    public BoardPanel getBoard() {
        return board;
    }

    public Top10 getTop10() {
        return top10;
    }

    public boolean isTop10Score(int score) {
        return top10.esTop10(score);
    }

    public void updateTop10(RegistroTop10 record) {
        top10.agregarRegistro(record.darNombre(), record.darPuntos());
    }

    public void saveTop10() throws FileNotFoundException, UnsupportedEncodingException {
        top10.salvarRecords(top10File);
    }
}

